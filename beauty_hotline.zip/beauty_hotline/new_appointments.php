<?php
session_start();

if (!isset($_SESSION['loggedin'])) {
    header('Location: admin.php');
    exit;
}

include_once 'includes/Database.php';
include_once 'includes/Appointment.php';

$database = new Database();
$db = $database->getConnection();

$appointment = new Appointment($db);

// Handle status update
if (isset($_GET['action']) && isset($_GET['id'])) {
    $id = $_GET['id'];
    $action = $_GET['action'];
    
    if ($action === 'accept') {
        $appointment->updateStatus($id, 'accepted');
    } elseif ($action === 'reject') {
        $appointment->updateStatus($id, 'rejected');
    }
    
    header('Location: new_appointments.php');
    exit;
}

// Get all pending appointments
$appointments = $appointment->readAll('pending');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>New Appointments - Beauty Hotline</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Great+Vibes&family=Pacifico&family=Playfair+Display:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(135deg, #f8f9fa, #e9ecef);
            margin: 0;
            padding: 0;
            min-height: 100vh;
            position: relative;
            padding-bottom: 60px;
        }
        .navbar {
            background: linear-gradient(135deg, #ffd700, #b8860b);
            padding: 1rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .navbar-brand {
            font-size: 24px;
            font-weight: 700;
            color: #000;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .navbar-brand:hover {
            color: #fff;
        }
        .logout-btn {
            background-color: #dc3545;
            color: #fff;
            border: none;
            padding: 8px 16px;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .logout-btn:hover {
            background-color: #c82333;
        }
        .dashboard-container {
            padding: 2rem;
        }
        .appointments-card {
            background: #fff;
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            margin-bottom: 2rem;
            overflow: hidden;
        }
        .appointments-header {
            background: linear-gradient(135deg, #ffd700, #b8860b);
            color: #000;
            padding: 1.5rem;
            border-bottom: 1px solid #eee;
        }
        .appointments-title {
            font-family: 'Playfair Display', serif;
            font-weight: 700;
            margin: 0;
        }
        .appointments-body {
            padding: 2rem;
        }
        .table-responsive {
            overflow-x: auto;
        }
        .appointments-table {
            width: 100%;
            border-collapse: collapse;
        }
        .appointments-table th {
            background-color: #f8f9fa;
            color: #495057;
            font-weight: 600;
            padding: 1rem;
            text-align: left;
            border-bottom: 2px solid #dee2e6;
        }
        .appointments-table td {
            padding: 1rem;
            border-bottom: 1px solid #dee2e6;
            vertical-align: top;
        }
        .appointments-table tr:hover {
            background-color: rgba(255, 215, 0, 0.1);
        }
        .btn-back {
            background-color: #6c757d;
            color: white;
            margin-bottom: 1.5rem;
            transition: all 0.3s;
        }
        .btn-back:hover {
            background-color: #5a6268;
            color: white;
            transform: translateY(-2px);
        }
        .no-appointments {
            text-align: center;
            padding: 2rem;
            color: #6c757d;
        }
        .footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 1rem;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
        .btn-accept {
            background-color: #28a745;
            color: white;
        }
        .btn-reject {
            background-color: #dc3545;
            color: white;
        }
        .type-home {
            color: #28a745;
            font-weight: bold;
        }
        .type-salon {
            color: #007bff;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar">
        <div class="container-fluid">
            <a class="navbar-brand" href="dashboard.php">Beauty Hotline Admin Panel</a>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="dashboard-container">
        <div class="appointments-card">
            <div class="appointments-header">
                <h2 class="appointments-title"><i class="fas fa-calendar-plus me-2"></i>New Appointments</h2>
            </div>
            <div class="appointments-body">
                <?php if ($appointments->rowCount() > 0): ?>
                    <div class="table-responsive">
                        <table class="appointments-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Date</th>
                                    <th>Time</th>
                                    <th>Services</th>
                                    <th>Type</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($row = $appointments->fetch(PDO::FETCH_ASSOC)): ?>
                                    <tr>
                                        <td><?php echo $row['id']; ?></td>
                                        <td><?php echo htmlspecialchars($row['name']); ?></td>
                                        <td><?php echo htmlspecialchars($row['email']); ?></td>
                                        <td><?php echo htmlspecialchars($row['phone']); ?></td>
                                        <td><?php echo date('M j, Y', strtotime($row['date'])); ?></td>
                                        <td><?php echo date('g:i A', strtotime($row['time'])); ?></td>
                                        <td><?php echo htmlspecialchars($row['services']); ?></td>
                                        <td>
                                            <span class="type-<?php echo htmlspecialchars($row['type']); ?>">
                                                <?php 
                                                echo ucfirst(htmlspecialchars($row['type'])); 
                                                echo $row['type'] === 'home' ? ' Service' : ' Appointment';
                                                ?>
                                            </span>
                                        </td>
                                        <td>
                                            <a href="?action=accept&id=<?php echo $row['id']; ?>" class="btn btn-sm btn-accept me-1">
                                                <i class="fas fa-check"></i> Accept
                                            </a>
                                            <a href="?action=reject&id=<?php echo $row['id']; ?>" class="btn btn-sm btn-reject">
                                                <i class="fas fa-times"></i> Reject
                                            </a>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="no-appointments">
                        <i class="fas fa-calendar-check fa-3x mb-3" style="color: #6c757d;"></i>
                        <h4>No new appointments</h4>
                        <p>There are no pending appointments to display.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <p>© 2025 Beauty Hotline Admin Panel. All rights reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
require_once 'includes/User.php'; // Corrected path to User.php

$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = new User();
    $existingUser = $user->findUserByEmail($_POST['email']);
    
    if ($existingUser) {
        $new_password = $_POST['new_password'];
        $user->resetPassword($_POST['email'], $new_password);
        // Redirect to login page after successful password reset
        header("Location: admin.php?reset=success");
        exit();
    } else {
        $error_message = "Incorrect email address.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Great+Vibes&family=Pacifico&family=Playfair+Display:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-image: url('assets/salon.jpg'); /* Replace with your image path */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .forgot-password-container {
            background: rgba(255, 255, 255, 0.8); /* Semi-transparent white background */
            padding: 2.5rem;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            width: 400px;
            text-align: center;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .forgot-password-container:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.4);
        }
        .forgot-password-container h1 {
            margin-bottom: 1.5rem;
            font-size: 32px;
            color: #ffd700; /* Gold text */
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .forgot-password-container input[type="email"],
        .forgot-password-container input[type="password"] {
            width: 100%;
            padding: 12px 15px;
            margin: 0.5rem 0 1rem;
            border: 2px solid #ffd700; /* Gold border */
            border-radius: 8px;
            box-sizing: border-box;
            font-size: 16px;
            transition: border-color 0.3s ease;
        }
        .forgot-password-container input[type="text"]:focus,
        .forgot-password-container input[type="password"]:focus {
            border-color: #b8860b; /* Darker gold on focus */
            outline: none;
        }
        .forgot-password-container button {
            width: 100%;
            padding: 12px;
            background-color: #ffd700; /* Gold button color */
            border: none;
            border-radius: 8px;
            color: #000; /* Black text */
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }
        .forgot-password-container button:hover {
            background-color: #b8860b; /* Dark gold on hover */
            transform: scale(1.02);
        }
        .forgot-password-container button:active {
            transform: scale(0.98);
        }
        .error-message {
            color: #721c24; /* Dark red for error messages */
            margin: 0.5rem 0;
            font-size: 14px;
            font-weight: 500;
        }
        .back-to-login {
            margin-top: 1rem;
            text-decoration: none;
            color: #ffd700; /* Gold for links */
            font-size: 14px;
        }
        .back-to-login:hover {
            text-decoration: underline;
            color: #b8860b; /* Darker gold on hover */
        }
    </style>
</head>
<body>
    <div class="forgot-password-container">
        <h1>Reset Password</h1>

        <!-- Forgot Password Form -->
        <form method="post" action="">
            <input type="email" name="email" placeholder="Enter your email" required>
            <input type="password" name="new_password" placeholder="New Password" required>
            <button type="submit">Reset Password</button>
        </form>

        <?php if (isset($error_message) && $error_message): ?>
            <p class="error-message"><?php echo htmlspecialchars($error_message); ?></p>
        <?php endif; ?>

        <a href="admin.php" class="back-to-login">Back to Login</a>
    </div>
</body>
</html>
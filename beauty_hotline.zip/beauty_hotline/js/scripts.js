// Function to add service to salon appointment
function addService() {
    const dropdown = document.getElementById('servicesDropdown');
    const selectedService = dropdown.value;
    const servicesList = document.getElementById('servicesList');
    
    if (!selectedService) return;
    
    // Check if service already exists
    const existingServices = servicesList.querySelectorAll('.service-item');
    for (let item of existingServices) {
        if (item.dataset.service === selectedService) {
            alert('This service has already been added!');
            return;
        }
    }
    
    // Create new service item
    const serviceItem = document.createElement('div');
    serviceItem.className = 'service-item d-flex justify-content-between align-items-center mb-2';
    serviceItem.dataset.service = selectedService;
    
    serviceItem.innerHTML = `
        <span>${selectedService}</span>
        <button type="button" class="btn btn-danger btn-sm" onclick="removeService(this)">
            <i class="fas fa-times"></i>
        </button>
    `;
    
    servicesList.appendChild(serviceItem);
    dropdown.value = ''; // Reset dropdown
    
    // Update hidden input with all selected services
    updateServicesInput();
}

// Function to add service to home appointment
function addHomeService() {
    const dropdown = document.getElementById('homeServicesDropdown');
    const selectedService = dropdown.value;
    const servicesList = document.getElementById('homeServicesList');
    
    if (!selectedService) return;
    
    // Check if service already exists
    const existingServices = servicesList.querySelectorAll('.service-item');
    for (let item of existingServices) {
        if (item.dataset.service === selectedService) {
            alert('This service has already been added!');
            return;
        }
    }
    
    // Create new service item
    const serviceItem = document.createElement('div');
    serviceItem.className = 'service-item d-flex justify-content-between align-items-center mb-2';
    serviceItem.dataset.service = selectedService;
    
    serviceItem.innerHTML = `
        <span>${selectedService}</span>
        <button type="button" class="btn btn-danger btn-sm" onclick="removeHomeService(this)">
            <i class="fas fa-times"></i>
        </button>
    `;
    
    servicesList.appendChild(serviceItem);
    dropdown.value = ''; // Reset dropdown
    
    // Update hidden input with all selected services
    updateHomeServicesInput();
}

// Function to remove service from salon appointment
function removeService(button) {
    const serviceItem = button.closest('.service-item');
    serviceItem.remove();
    updateServicesInput();
}

// Function to remove service from home appointment
function removeHomeService(button) {
    const serviceItem = button.closest('.service-item');
    serviceItem.remove();
    updateHomeServicesInput();
}

// Update hidden input for salon appointment
function updateServicesInput() {
    const servicesList = document.getElementById('servicesList');
    const servicesInput = document.getElementById('servicesInput');
    const services = [];
    
    servicesList.querySelectorAll('.service-item').forEach(item => {
        services.push(item.dataset.service);
    });
    
    servicesInput.value = services.join(', ');
}

// Update hidden input for home appointment
function updateHomeServicesInput() {
    const servicesList = document.getElementById('homeServicesList');
    const servicesInput = document.getElementById('homeServicesInput');
    const services = [];
    
    servicesList.querySelectorAll('.service-item').forEach(item => {
        services.push(item.dataset.service);
    });
    
    servicesInput.value = services.join(', ');
}

// Validate date for salon appointment
document.getElementById('date').addEventListener('change', function() {
    const selectedDate = new Date(this.value);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    if (selectedDate < today) {
        alert('Please select a date in the future.');
        this.value = '';
    }
});

// Validate date for home salon appointment
document.getElementById('homeDate').addEventListener('change', function() {
    const selectedDate = new Date(this.value);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    if (selectedDate < today) {
        alert('Please select a date in the future.');
        this.value = '';
    }
});

// Initialize when page loads
document.addEventListener('DOMContentLoaded', function() {
    // Update services inputs when forms are submitted
    const salonForm = document.getElementById('salonForm');
    if (salonForm) {
        salonForm.addEventListener('submit', function() {
            updateServicesInput();
        });
    }
    
    const homeSalonForm = document.getElementById('homeSalonForm');
    if (homeSalonForm) {
        homeSalonForm.addEventListener('submit', function() {
            updateHomeServicesInput();
        });
    }
});
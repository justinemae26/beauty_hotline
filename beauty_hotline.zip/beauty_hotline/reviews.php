<?php
include_once 'includes/Database.php';
include_once 'includes/Review.php';

$database = new Database();
$db = $database->getConnection();

$review = new Review($db);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $review->name = $_POST['name'];
    $review->email = $_POST['email'];
    $review->comment = $_POST['comment'];

    if ($review->create()) {
        $success_message = "Thank you for your feedback!";
    } else {
        $error_message = "Error submitting your feedback. Please try again.";
    }
}

// Get all reviews
$reviews = $review->readAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Customer Reviews - Beauty Hotline</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Great+Vibes&family=Pacifico&family=Playfair+Display:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <style>
        .feedback-btn {
            position: fixed;
            bottom: 30px;
            right: 30px;
            background-color: gold;
            color: black;
            border: none;
            width: 60px;
            height: 60px;
            border-radius: 50%;
            font-size: 24px;
            cursor: pointer;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            z-index: 1000;
            transition: all 0.3s ease;
        }
        .feedback-btn:hover {
            background-color: #ffd700;
            transform: scale(1.1);
        }
        .feedback-form-container {
            position: fixed;
            bottom: 100px;
            right: 30px;
            width: 350px;
            background-color: black;
            border: 2px solid gold;
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.3);
            z-index: 1000;
            display: none;
        }
        .feedback-form-container.show {
            display: block;
            animation: fadeIn 0.3s ease;
        }
        .feedback-form-container h3 {
            color: gold;
            margin-bottom: 20px;
            font-family: 'Playfair Display', serif;
            text-align: center;
        }
        .feedback-form-container .form-control {
            background-color: #222;
            color: white;
            border: 1px solid #444;
            margin-bottom: 15px;
        }
        .feedback-form-container .form-control::placeholder {
            color: #aaa;
        }
        .feedback-form-container .form-control:focus {
            background-color: #333;
            color: white;
            border-color: gold;
            box-shadow: 0 0 0 0.25rem rgba(255, 215, 0, 0.25);
        }
        .feedback-form-container .btn-submit {
            background-color: gold;
            color: black;
            font-weight: bold;
            width: 100%;
        }
        .feedback-form-container .btn-submit:hover {
            background-color: #ffd700;
        }
        .feedback-form-container .btn-close {
            position: absolute;
            top: 10px;
            right: 10px;
            color: gold;
            opacity: 1;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-black">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <img src="assets/logo.png" alt="Logo" height="50">
                <span class="logo-text">Beauty Hotline</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link" href="about.php">About</a></li>
                    <li class="nav-item"><a class="nav-link" href="services.php">Services</a></li>
                    <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
                    <li class="nav-item"><a class="nav-link" href="list.php">Appointments</a></li>
                    <li class="nav-item"><a class="nav-link" href="reviews.php">Reviews</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Banner Section -->
    <div class="banner">
        <div class="card">
            <h2>Beauty Hotline</h2>
            <p>Radiance Starts Here – Book Your Escape Today!</p>
        </div>
    </div>

    <!-- Reviews Section -->
<section class="reviews-section">
    <div class="container">
        <div class="card shadow">
            <h2 class="card-header bg-gold text-black">Customer Feedback</h2>
            <div class="card-body">
                <?php if($reviews->rowCount() > 0): ?>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Comment</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($row = $reviews->fetch(PDO::FETCH_ASSOC)): ?>
                                <tr>
                                    <td><?php echo $row['id']; ?></td>
                                    <td><?php echo htmlspecialchars($row['name']); ?></td>
                                    <td><?php echo htmlspecialchars($row['comment']); ?></td>
                                    <td><?php echo date('M j, Y', strtotime($row['date'])); ?></td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="alert alert-info">
                        No reviews yet. Be the first to share your experience!
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

    <!-- Floating Feedback Button -->
    <button class="feedback-btn" id="feedbackBtn">
        <i class="fas fa-comment-alt"></i>
    </button>

    <!-- Floating Feedback Form -->
    <div class="feedback-form-container" id="feedbackForm">
        <button type="button" class="btn-close" id="closeFeedbackForm"></button>
        <h3>Share Your Feedback</h3>
        <?php if (isset($success_message)): ?>
            <div class="alert alert-success"><?php echo $success_message; ?></div>
        <?php elseif (isset($error_message)): ?>
            <div class="alert alert-danger"><?php echo $error_message; ?></div>
        <?php endif; ?>
        <form method="post" action="">
            <div class="mb-3">
                <input type="text" class="form-control" name="name" placeholder="Your Name" required>
            </div>
            <div class="mb-3">
                <input type="email" class="form-control" name="email" placeholder="Your Email" required>
            </div>
            <div class="mb-3">
                <textarea class="form-control" name="comment" placeholder="Your Feedback" rows="4" required></textarea>
            </div>
            <button type="submit" class="btn btn-submit">Submit Feedback</button>
        </form>
    </div>

    <!-- Footer -->
    <footer class="footer text-center">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <h5 class="footer-brand">
                        <a href="index.php" class="footer-logo-link">
                            <img src="assets/logo.png" alt="Logo" height="50">
                            <span class="footer-logo-text">Beauty Hotline</span>
                        </a>
                    </h5>
                </div>
                <div class="col-md-3">
                    <h6>Quick Links</h6>
                    <p><a href="about.php">About</a></p>
                    <p><a href="services.php">Services</a></p>
                    <p><a href="contact.php">Contact</a></p>
                </div>
                <div class="col-md-3">
                    <h6>Customer</h6>
                    <p><a href="list.php">Appointments</a></p>
                    <p><a href="reviews.php">Reviews</a></p>
                    <p><a href="cancel.php">Cancel Appointment</a></p>
                </div>
                <div class="col-md-3">
                    <h6>Have A Question?</h6>
                    <p><i class="fa-solid fa-location-dot"></i> Piaping Itum Macabalan, Cagayan de Oro City</p>
                    <p><i class="fa-solid fa-phone"></i> 09534704484</p>
                    <p><i class="fa-solid fa-envelope"></i> beauty.hotline@gmail.com</p>
                </div>
            </div>
            <p class="social-icons">
                &copy; 2025 Beauty Hotline. All rights reserved.
                <a href="#"><i class="fab fa-facebook fa-2x mx-3"></i></a>
                <a href="#"><i class="fab fa-twitter fa-2x mx-3"></i></a>
                <a href="#"><i class="fab fa-instagram fa-2x mx-3"></i></a>
            </p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Floating feedback form functionality
        document.addEventListener('DOMContentLoaded', function() {
            const feedbackBtn = document.getElementById('feedbackBtn');
            const feedbackForm = document.getElementById('feedbackForm');
            const closeBtn = document.getElementById('closeFeedbackForm');
            
            feedbackBtn.addEventListener('click', function() {
                feedbackForm.classList.toggle('show');
            });
            
            closeBtn.addEventListener('click', function() {
                feedbackForm.classList.remove('show');
            });
            
            // Close form when clicking outside
            document.addEventListener('click', function(event) {
                if (!feedbackForm.contains(event.target) && event.target !== feedbackBtn) {
                    feedbackForm.classList.remove('show');
                }
            });
        });
    </script>
</body>
</html>
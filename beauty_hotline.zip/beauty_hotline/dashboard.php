<?php
session_start();

// Handle logout
if (isset($_GET['logout'])) {
    session_unset();
    session_destroy();
    header('Location: admin.php');
    exit;
}

if (!isset($_SESSION['loggedin'])) {
    header('Location: admin.php');
    exit;
}

include_once 'includes/Database.php';
include_once 'includes/Appointment.php';
include_once 'includes/Review.php';
include_once 'includes/Service.php';
include_once 'includes/Sale.php';

$database = new Database();
$db = $database->getConnection();

$appointment = new Appointment($db);
$review = new Review($db);
$service = new Service($db);
$sale = new Sale($db);

// Count pending appointments
$pending_appointments = $appointment->readAll('pending');
$pending_count = $pending_appointments->rowCount();

// Count accepted appointments
$accepted_appointments = $appointment->readAll('accepted');
$accepted_count = $accepted_appointments->rowCount();

// Count rejected appointments
$rejected_appointments = $appointment->readAll('rejected');
$rejected_count = $rejected_appointments->rowCount();

// Count services
$services = $service->readAll();
$services_count = $services->rowCount();

// Count reviews
$reviews = $review->readAll();
$reviews_count = $reviews->rowCount();

// Get total sales
$total_sales = $sale->getTotalSales();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Beauty Hotline Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Great+Vibes&family=Pacifico&family=Playfair+Display:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(135deg, #f8f9fa, #e9ecef);
            margin: 0;
            padding: 0;
            min-height: 100vh;
            position: relative;
            padding-bottom: 60px;
        }
        .navbar {
            background: linear-gradient(135deg, #ffd700, #b8860b);
            padding: 1rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .navbar-brand {
            font-size: 24px;
            font-weight: 700;
            color: #000;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .navbar-brand:hover {
            color: #fff;
        }
        .logout-btn {
            background-color: #dc3545;
            color: #fff;
            border: none;
            padding: 8px 16px;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .logout-btn:hover {
            background-color: #c82333;
        }
        .dashboard-container {
            padding: 2rem;
        }
        .card {
            background: #fff;
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            cursor: pointer;
            overflow: hidden;
        }
        .card:hover {
            transform: translateY(-10px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }
        .card-body {
            padding: 2rem;
            text-align: center;
        }
        .card-title {
            font-size: 20px;
            font-weight: 700;
            color: #333;
            margin-bottom: 1rem;
        }
        .card-value {
            font-size: 32px;
            font-weight: 700;
            color: #ffd700;
            margin-bottom: 1rem;
        }
        .card-icon {
            font-size: 48px;
            color: #ffd700;
            margin-bottom: 1rem;
        }
        .footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 1rem;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar">
        <div class="container-fluid">
            <a class="navbar-brand" href="dashboard.php">Beauty Hotline Admin Panel</a>
            <a href="?logout=true" class="logout-btn">Logout</a>
        </div>
    </nav>

    <!-- Dashboard Content -->
    <div class="dashboard-container">
        <div class="row">
            <!-- Total Services Card -->
            <div class="col-md-4 mb-4">
                <div class="card" onclick="window.location.href='admin_services.php'">
                    <div class="card-body">
                        <i class="fas fa-spa card-icon"></i>
                        <h3 class="card-title">Total Services</h3>
                        <p class="card-value"><?php echo $services_count; ?></p>
                    </div>
                </div>
            </div>

            <!-- Total Sales Card -->
            <div class="col-md-4 mb-4">
                <div class="card" onclick="window.location.href='sales.php'">
                    <div class="card-body">
                        <i class="fas fa-dollar-sign card-icon"></i>
                        <h3 class="card-title">Total Sales</h3>
                        <p class="card-value">₱<?php echo number_format($total_sales, 2); ?></p>
                    </div>
                </div>
            </div>

            <!-- Total Reviews Card -->
            <div class="col-md-4 mb-4">
                <div class="card" onclick="window.location.href='admin_reviews.php'">
                    <div class="card-body">
                        <i class="fas fa-star card-icon"></i>
                        <h3 class="card-title">Total Reviews</h3>
                        <p class="card-value"><?php echo $reviews_count; ?></p>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <!-- New Appointments Card -->
            <div class="col-md-4 mb-4">
                <div class="card" onclick="window.location.href='new_appointments.php'">
                    <div class="card-body">
                        <i class="fas fa-calendar-plus card-icon"></i>
                        <h3 class="card-title">New Appointments</h3>
                        <p class="card-value"><?php echo $pending_count; ?></p>
                    </div>
                </div>
            </div>

            <!-- Accepted Appointments Card -->
            <div class="col-md-4 mb-4">
                <div class="card" onclick="window.location.href='accepted_appointments.php'">
                    <div class="card-body">
                        <i class="fas fa-check-circle card-icon"></i>
                        <h3 class="card-title">Accepted Appointments</h3>
                        <p class="card-value"><?php echo $accepted_count; ?></p>
                    </div>
                </div>
            </div>

            <!-- Rejected Appointments Card -->
            <div class="col-md-4 mb-4">
                <div class="card" onclick="window.location.href='rejected_appointments.php'">
                    <div class="card-body">
                        <i class="fas fa-times-circle card-icon"></i>
                        <h3 class="card-title">Rejected Appointments</h3>
                        <p class="card-value"><?php echo $rejected_count; ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <p>© 2025 Beauty Hotline Admin Panel. All rights reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
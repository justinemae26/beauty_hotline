<?php
include_once 'includes/Database.php';
include_once 'includes/Appointment.php';

$database = new Database();
$db = $database->getConnection();

$appointment = new Appointment($db);

// Get all accepted appointments
$accepted_appointments = $appointment->readAll('accepted');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Appointment List - Beauty Hotline</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Great+Vibes&family=Pacifico&family=Playfair+Display:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-black">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <img src="assets/logo.png" alt="Logo" height="50">
                <span class="logo-text">Beauty Hotline</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link" href="about.php">About</a></li>
                    <li class="nav-item"><a class="nav-link" href="services.php">Services</a></li>
                    <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
                    <li class="nav-item"><a class="nav-link" href="list.php">Appointments</a></li>
                    <li class="nav-item"><a class="nav-link" href="reviews.php">Reviews</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Banner Section -->
    <div class="banner">
        <div class="card">
            <h2>Beauty Hotline</h2>
            <p>Radiance Starts Here – Book Your Escape Today!</p>
        </div>
    </div>

    <!-- Appointment List Section -->
    <div class="container my-5">
        <div class="card shadow">
            <div class="card-header bg-gold text-black">
                <h3 class="mb-0">Accepted Appointments</h3>
            </div>
            <div class="card-body">
                <?php if($accepted_appointments->rowCount() > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Date</th>
                                <th>Time</th>
                                <th>Services</th>
                                <th>Type</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = $accepted_appointments->fetch(PDO::FETCH_ASSOC)): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['id']); ?></td>
                                <td><?php echo htmlspecialchars($row['name']); ?></td>
                                <td><?php echo date('F j, Y', strtotime($row['date'])); ?></td>
                                <td><?php echo date('g:i A', strtotime($row['time'])); ?></td>
                                <td><?php echo htmlspecialchars($row['services']); ?></td>
                                <td><?php echo ucfirst(htmlspecialchars($row['type'])); ?></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                <div class="alert alert-info">
                    No accepted appointments found.
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer text-center">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <h5 class="footer-brand">
                        <a href="index.php" class="footer-logo-link">
                            <img src="assets/logo.png" alt="Logo" height="50">
                            <span class="footer-logo-text">Beauty Hotline</span>
                        </a>
                    </h5>
                </div>
                <div class="col-md-3">
                    <h6>Quick Links</h6>
                    <p><a href="about.php">About</a></p>
                    <p><a href="services.php">Services</a></p>
                    <p><a href="contact.php">Contact</a></p>
                </div>
                <div class="col-md-3">
                    <h6>Customer</h6>
                    <p><a href="list.php">Appointments</a></p>
                    <p><a href="reviews.php">Reviews</a></p>
                    <p><a href="cancel.php">Cancel Appointment</a></p>
                </div>
                <div class="col-md-3">
                    <h6>Have A Question?</h6>
                    <p><i class="fa-solid fa-location-dot"></i> Piaping Itum Macabalan, Cagayan de Oro City</p>
                    <p><i class="fa-solid fa-phone"></i> 09534704484</p>
                    <p><i class="fa-solid fa-envelope"></i> beauty.hotline@gmail.com</p>
                </div>
            </div>
            <p class="social-icons">
                &copy; 2025 Beauty Hotline. All rights reserved.
                <a href="#"><i class="fab fa-facebook fa-2x mx-3"></i></a>
                <a href="#"><i class="fab fa-twitter fa-2x mx-3"></i></a>
                <a href="#"><i class="fab fa-instagram fa-2x mx-3"></i></a>
            </p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
session_start();
require_once 'includes/User.php'; // Corrected path to User.php

$error_message = '';
$success_message = '';

if (isset($_GET['reset']) && $_GET['reset'] === 'success') {
    $success_message = "Password reset successful. Please log in with your new password.";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = new User();
    $login = $user->login($_POST['username'], $_POST['password']);

    if ($login) {
        $_SESSION['username'] = $login['username'];
        $_SESSION['loggedin'] = true; // Set session variable to indicate user is logged in
        header("Location: dashboard.php"); // Redirect to dashboard.php
        exit();
    } else {
        $error_message = "Incorrect username or password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Great+Vibes&family=Pacifico&family=Playfair+Display:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-image: url('assets/salon.jpg'); /* Replace with your image path */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .login-container {
            background: rgba(255, 255, 255, 0.8); /* Semi-transparent white background */
            padding: 2.5rem;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            width: 400px;
            text-align: center;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .login-container:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.4);
        }
        .login-container h1 {
            margin-bottom: 1.5rem;
            font-size: 32px;
            color: #ffd700; /* Gold text */
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .login-container input[type="text"],
        .login-container input[type="password"] {
            width: 100%;
            padding: 12px 15px;
            margin: 0.5rem 0 1rem;
            border: 2px solid #ffd700; /* Gold border */
            border-radius: 8px;
            box-sizing: border-box;
            font-size: 16px;
            transition: border-color 0.3s ease;
        }
        .login-container input[type="text"]:focus,
        .login-container input[type="password"]:focus {
            border-color: #b8860b; /* Darker gold on focus */
            outline: none;
        }
        .login-container button {
            width: 100%;
            padding: 12px;
            background-color: #ffd700; /* Gold button color */
            border: none;
            border-radius: 8px;
            color: #000; /* Black text */
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }
        .login-container button:hover {
            background-color: #b8860b; /* Dark gold on hover */
            transform: scale(1.02);
        }
        .login-container button:active {
            transform: scale(0.98);
        }
        .error-message {
            color: #721c24; /* Dark red for error messages */
            margin: 0.5rem 0;
            font-size: 14px;
            font-weight: 500;
        }
        .success-message {
            color: #3c763d; /* Dark green for success messages */
            margin: 0.5rem 0;
            font-size: 14px;
            font-weight: 500;
        }
        .forgot-password {
            margin-top: 1rem;
            text-decoration: none;
            color: #ffd700; /* Gold for links */
            font-size: 14px;
            font-weight: 500;
            transition: color 0.3s ease;
        }
        .forgot-password:hover {
            text-decoration: underline;
            color: #b8860b; /* Darker gold on hover */
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h1>Admin Login</h1>

        <!-- Login Form -->
        <form method="post" action="">
            <div>
                <input type="text" name="username" placeholder="Username" required>
            </div>
            <div class="password-container" style="position: relative;">
                <input type="password" name="password" id="password" placeholder="Password" required>
            </div>
            <button type="submit">Login</button>
        </form>

        <!-- Error and Success Messages -->
        <?php if (isset($error_message) && $error_message): ?>
            <p class="error-message"><?php echo htmlspecialchars($error_message); ?></p>
        <?php elseif (isset($success_message) && $success_message): ?>
            <p class="success-message"><?php echo htmlspecialchars($success_message); ?></p>
        <?php endif; ?>

        <a href="forgot_password.php" class="forgot-password">Forgot Password?</a>
    </div>
</body>
</html>
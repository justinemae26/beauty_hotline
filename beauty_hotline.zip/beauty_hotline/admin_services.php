<?php
session_start();

if (!isset($_SESSION['loggedin'])) {
    header('Location: admin.php');
    exit;
}

include_once 'includes/Database.php';
include_once 'includes/Service.php';

$database = new Database();
$db = $database->getConnection();

$service = new Service($db);

// Handle form submission for adding new service
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_service'])) {
    $service->category = $_POST['category'];
    $service->name = $_POST['name'];
    $service->description = $_POST['description'];
    $service->price = $_POST['price'];
    
    if ($service->create()) {
        $success_message = "Service added successfully!";
    } else {
        $error_message = "Failed to add service. Please try again.";
    }
}

// Handle service deletion
if (isset($_GET['delete'])) {
    $service->id = $_GET['delete'];
    if ($service->delete()) {
        $success_message = "Service deleted successfully!";
    } else {
        $error_message = "Failed to delete service.";
    }
    header('Location: admin_services.php');
    exit;
}

// Get all services ordered by ID
$services = $service->readAll('id ASC');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Services - Beauty Hotline</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Great+Vibes&family=Pacifico&family=Playfair+Display:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(135deg, #f8f9fa, #e9ecef);
            margin: 0;
            padding: 0;
            min-height: 100vh;
            position: relative;
            padding-bottom: 60px;
        }
        .navbar {
            background: linear-gradient(135deg, #ffd700, #b8860b);
            padding: 1rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .navbar-brand {
            font-size: 24px;
            font-weight: 700;
            color: #000;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .navbar-brand:hover {
            color: #fff;
        }
        .logout-btn {
            background-color: #dc3545;
            color: #fff;
            border: none;
            padding: 8px 16px;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .logout-btn:hover {
            background-color: #c82333;
        }
        .dashboard-container {
            padding: 2rem;
        }
        .services-card {
            background: #fff;
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            margin-bottom: 2rem;
            overflow: hidden;
        }
        .services-header {
            background: linear-gradient(135deg, #ffd700, #b8860b);
            color: #000;
            padding: 1.5rem;
            border-bottom: 1px solid #eee;
        }
        .services-title {
            font-family: 'Playfair Display', serif;
            font-weight: 700;
            margin: 0;
        }
        .services-body {
            padding: 2rem;
        }
        .table-responsive {
            overflow-x: auto;
        }
        .services-table {
            width: 100%;
            border-collapse: collapse;
        }
        .services-table th {
            background-color: #f8f9fa;
            color: #495057;
            font-weight: 600;
            padding: 1rem;
            text-align: left;
            border-bottom: 2px solid #dee2e6;
        }
        .services-table td {
            padding: 1rem;
            border-bottom: 1px solid #dee2e6;
            vertical-align: top;
        }
        .services-table tr:hover {
            background-color: rgba(255, 215, 0, 0.1);
        }
        .btn-back {
            background-color: #6c757d;
            color: white;
            margin-bottom: 1.5rem;
            transition: all 0.3s;
        }
        .btn-back:hover {
            background-color: #5a6268;
            color: white;
            transform: translateY(-2px);
        }
        .no-services {
            text-align: center;
            padding: 2rem;
            color: #6c757d;
        }
        .footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 1rem;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
        .btn-add {
            background-color: #28a745;
            color: white;
            margin-bottom: 1.5rem;
        }
        .btn-edit {
            background-color: #17a2b8;
            color: white;
        }
        .btn-delete {
            background-color: #dc3545;
            color: white;
        }
        .bg-gold {
            background: linear-gradient(135deg, #ffd700, #b8860b);
        }
        .btn-gold {
            background: linear-gradient(135deg, #ffd700, #b8860b);
            color: #000;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar">
        <div class="container-fluid">
            <a class="navbar-brand" href="dashboard.php">Beauty Hotline Admin Panel</a>
            <form action="logout.php" method="post">
                <button type="submit" class="logout-btn">
                    <i class="fas fa-sign-out-alt me-1"></i>Logout
                </button>
            </form>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="dashboard-container">
        <button class="btn btn-add" data-bs-toggle="modal" data-bs-target="#addServiceModal">
            <i class="fas fa-plus me-2"></i>Add New Service
        </button>

        <div class="services-card">
            <div class="services-header">
                <h2 class="services-title"><i class="fas fa-spa me-2"></i>Manage Services</h2>
            </div>
            <div class="services-body">
                <?php if (isset($success_message)): ?>
                    <div class="alert alert-success"><?php echo $success_message; ?></div>
                <?php elseif (isset($error_message)): ?>
                    <div class="alert alert-danger"><?php echo $error_message; ?></div>
                <?php endif; ?>

                <?php if ($services->rowCount() > 0): ?>
                    <div class="table-responsive">
                        <table class="services-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Category</th>
                                    <th>Name</th>
                                    <th>Description</th>
                                    <th>Price</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($row = $services->fetch(PDO::FETCH_ASSOC)): ?>
                                    <tr>
                                        <td><?php echo $row['id']; ?></td>
                                        <td><?php echo htmlspecialchars($row['category']); ?></td>
                                        <td><?php echo htmlspecialchars($row['name']); ?></td>
                                        <td><?php echo htmlspecialchars($row['description']); ?></td>
                                        <td>₱<?php echo number_format($row['price'], 2); ?></td>
                                        <td>
                                            <a href="edit_service.php?id=<?php echo $row['id']; ?>" class="btn btn-sm btn-edit me-1">
                                                <i class="fas fa-edit"></i> Edit
                                            </a>
                                            <a href="admin_services.php?delete=<?php echo $row['id']; ?>" class="btn btn-sm btn-delete" onclick="return confirm('Are you sure you want to delete this service?')">
                                                <i class="fas fa-trash"></i> Delete
                                            </a>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="no-services">
                        <i class="fas fa-spa fa-3x mb-3" style="color: #6c757d;"></i>
                        <h4>No services found</h4>
                        <p>There are no services to display. Add a new service to get started.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Add Service Modal -->
    <div class="modal fade" id="addServiceModal" tabindex="-1" aria-labelledby="addServiceModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-gold text-black">
                    <h5 class="modal-title" id="addServiceModalLabel">Add New Service</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form method="post" action="">
                        <div class="mb-3">
                            <label for="category" class="form-label">Category</label>
                            <select class="form-control" id="category" name="category" required>
                                <option value="">Select a category</option>
                                <option value="Hair Services">Hair Services</option>
                                <option value="Makeup Services">Makeup Services</option>
                                <option value="Nail Services">Nail Services</option>
                                <option value="Eyebrow and Eyelash Services">Eyebrow and Eyelash Services</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="name" class="form-label">Service Name</label>
                            <input type="text" class="form-control" id="name" name="name" required>
                        </div>
                        <div class="mb-3">
                            <label for="description" class="form-label">Description</label>
                            <textarea class="form-control" id="description" name="description" rows="3" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="price" class="form-label">Price</label>
                            <input type="number" class="form-control" id="price" name="price" step="0.01" min="0" required>
                        </div>
                        <button type="submit" name="add_service" class="btn btn-gold w-100">Add Service</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <p>© 2025 Beauty Hotline Admin Panel. All rights reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
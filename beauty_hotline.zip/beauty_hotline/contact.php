<?php
include_once 'includes/Database.php';

$database = new Database();
$db = $database->getConnection();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Contact Us - Beauty Hotline</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Great+Vibes&family=Pacifico&family=Playfair+Display:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <style>
        /* Custom footer style that's full width and not card-like */
        .full-width-footer {
            background: #000;
            color: white;
            padding: 40px 0;
            margin-top: 50px;
            width: 100%;
        }
        .full-width-footer a {
            color: #ffd700;
            text-decoration: none;
        }
        .full-width-footer a:hover {
            color: #fff;
        }
        .full-width-footer h5, 
        .full-width-footer h6 {
            color: #ffd700;
            margin-bottom: 20px;
        }
        .full-width-footer .social-icons a {
            color: white;
            font-size: 24px;
            margin: 0 15px;
            transition: all 0.3s ease;
        }
        .full-width-footer .social-icons a:hover {
            color: #ffd700;
            transform: translateY(-3px);
        }
        .full-width-footer .copyright {
            margin-top: 30px;
            color: #aaa;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-black">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <img src="assets/logo.png" alt="Logo" height="50">
                <span class="logo-text">Beauty Hotline</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link" href="about.php">About</a></li>
                    <li class="nav-item"><a class="nav-link" href="services.php">Services</a></li>
                    <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
                    <li class="nav-item"><a class="nav-link" href="list.php">Appointments</a></li>
                    <li class="nav-item"><a class="nav-link" href="reviews.php">Reviews</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Banner Section -->
    <div class="banner">
        <div class="card">
            <h2>Beauty Hotline</h2>
            <p>Radiance Starts Here – Book Your Escape Today!</p>
        </div>
    </div>

    <!-- Contact Section -->
    <div class="contact-section container">
        <div class="contact-title">Contact Us</div>
        <div class="row text-center">
            <div class="col-md-3">
                <div class="info-box">
                    <i class="fa-solid fa-map-signs"></i>
                    <h5>Address</h5>
                    <p>Piaping Itum Macabalan, Cagayan de Oro City</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="info-box">
                    <i class="fa-solid fa-phone"></i>
                    <h5>Contact Number</h5>
                    <p>09534704484</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="info-box">
                    <i class="fa-solid fa-paper-plane"></i>
                    <h5>Email Address</h5>
                    <p>beauty.hotline@gmail.com</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="info-box">
                    <i class="fa-solid fa-globe"></i>
                    <h5>Timing</h5>
                    <p>8:00 am to 8:00 pm</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Full Width Footer -->
    <footer class="full-width-footer">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <h5 class="footer-brand">
                        <a href="index.php" class="d-flex align-items-center">
                            <img src="assets/logo.png" alt="Logo" height="50" class="me-2">
                            <span class="footer-logo-text">Beauty Hotline</span>
                        </a>
                    </h5>
                </div>
                <div class="col-md-3">
                    <h6>Quick Links</h6>
                    <p><a href="about.php">About</a></p>
                    <p><a href="services.php">Services</a></p>
                    <p><a href="contact.php">Contact</a></p>
                </div>
                <div class="col-md-3">
                    <h6>Customer</h6>
                    <p><a href="list.php">Appointments</a></p>
                    <p><a href="reviews.php">Reviews</a></p>
                    <p><a href="cancel.php">Cancel Appointment</a></p>
                </div>
                <div class="col-md-3">
                    <h6>Have A Question?</h6>
                    <p><i class="fa-solid fa-location-dot me-2"></i>Piaping Itum Macabalan, Cagayan de Oro City</p>
                    <p><i class="fa-solid fa-phone me-2"></i>09534704484</p>
                    <p><i class="fa-solid fa-envelope me-2"></i>beauty.hotline@gmail.com</p>
                </div>
            </div>
            <div class="text-center mt-4">
                <div class="social-icons">
                    <a href="#"><i class="fab fa-facebook"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                </div>
                <p class="copyright mt-3">&copy; 2025 Beauty Hotline. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
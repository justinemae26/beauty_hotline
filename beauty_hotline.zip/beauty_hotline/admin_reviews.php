<?php
session_start();

if (!isset($_SESSION['loggedin'])) {
    header('Location: admin.php');
    exit;
}

include_once 'includes/Database.php';
include_once 'includes/Review.php';

$database = new Database();
$db = $database->getConnection();

$review = new Review($db);

// Get all reviews
$reviews = $review->readAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Reviews - Beauty Hotline</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Great+Vibes&family=Pacifico&family=Playfair+Display:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(135deg, #f8f9fa, #e9ecef);
            margin: 0;
            padding: 0;
            min-height: 100vh;
            position: relative;
            padding-bottom: 60px;
        }
        .navbar {
            background: linear-gradient(135deg, #ffd700, #b8860b);
            padding: 1rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .navbar-brand {
            font-size: 24px;
            font-weight: 700;
            color: #000;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .navbar-brand:hover {
            color: #fff;
        }
        .logout-btn {
            background-color: #dc3545;
            color: #fff;
            border: none;
            padding: 8px 16px;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .logout-btn:hover {
            background-color: #c82333;
        }
        .dashboard-container {
            padding: 2rem;
        }
        .reviews-card {
            background: #fff;
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            margin-bottom: 2rem;
            overflow: hidden;
        }
        .reviews-header {
            background: linear-gradient(135deg, #ffd700, #b8860b);
            color: #000;
            padding: 1.5rem;
            border-bottom: 1px solid #eee;
        }
        .reviews-title {
            font-family: 'Playfair Display', serif;
            font-weight: 700;
            margin: 0;
        }
        .reviews-body {
            padding: 2rem;
        }
        .table-responsive {
            overflow-x: auto;
        }
        .reviews-table {
            width: 100%;
            border-collapse: collapse;
        }
        .reviews-table th {
            background-color: #f8f9fa;
            color: #495057;
            font-weight: 600;
            padding: 1rem;
            text-align: left;
            border-bottom: 2px solid #dee2e6;
        }
        .reviews-table td {
            padding: 1rem;
            border-bottom: 1px solid #dee2e6;
            vertical-align: top;
        }
        .reviews-table tr:hover {
            background-color: rgba(255, 215, 0, 0.1);
        }
        .btn-back {
            background-color: #6c757d;
            color: white;
            margin-bottom: 1.5rem;
            transition: all 0.3s;
        }
        .btn-back:hover {
            background-color: #5a6268;
            color: white;
            transform: translateY(-2px);
        }
        .no-reviews {
            text-align: center;
            padding: 2rem;
            color: #6c757d;
        }
        .footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 1rem;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
        .comment-cell {
            max-width: 300px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .comment-cell:hover {
            white-space: normal;
            overflow: visible;
            position: absolute;
            background: white;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            z-index: 100;
            max-width: 500px;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar">
        <div class="container-fluid">
            <a class="navbar-brand" href="dashboard.php">Beauty Hotline Admin Panel</a>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="dashboard-container">
        <div class="reviews-card">
            <div class="reviews-header">
                <h2 class="reviews-title"><i class="fas fa-star me-2"></i>Customer Reviews</h2>
            </div>
            <div class="reviews-body">
                <?php if ($reviews->rowCount() > 0): ?>
                    <div class="table-responsive">
                        <table class="reviews-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Comment</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($row = $reviews->fetch(PDO::FETCH_ASSOC)): ?>
                                    <tr>
                                        <td><?php echo $row['id']; ?></td>
                                        <td><?php echo htmlspecialchars($row['name']); ?></td>
                                        <td><?php echo htmlspecialchars($row['email']); ?></td>
                                        <td class="comment-cell"><?php echo htmlspecialchars($row['comment']); ?></td>
                                        <td><?php echo date('M j, Y', strtotime($row['date'])); ?></td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="no-reviews">
                        <i class="fas fa-comment-slash fa-3x mb-3" style="color: #6c757d;"></i>
                        <h4>No reviews found</h4>
                        <p>There are no customer reviews to display.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <p>© 2025 Beauty Hotline Admin Panel. All rights reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
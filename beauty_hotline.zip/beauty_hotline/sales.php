<?php
session_start();

if (!isset($_SESSION['loggedin'])) {
    header('Location: admin.php');
    exit;
}

include_once 'includes/Database.php';
include_once 'includes/Sale.php';

$database = new Database();
$db = $database->getConnection();

$sale = new Sale($db);

// Get all sales
$sales = $sale->readAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sales - Beauty Hotline</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Great+Vibes&family=Pacifico&family=Playfair+Display:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(135deg, #f8f9fa, #e9ecef);
            margin: 0;
            padding: 0;
            min-height: 100vh;
            position: relative;
            padding-bottom: 60px;
        }
        .navbar {
            background: linear-gradient(135deg, #ffd700, #b8860b);
            padding: 1rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .navbar-brand {
            font-size: 24px;
            font-weight: 700;
            color: #000;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .navbar-brand:hover {
            color: #fff;
        }
        .logout-btn {
            background-color: #dc3545;
            color: #fff;
            border: none;
            padding: 8px 16px;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .logout-btn:hover {
            background-color: #c82333;
        }
        .dashboard-container {
            padding: 2rem;
        }
        .sales-card {
            background: #fff;
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            margin-bottom: 2rem;
            overflow: hidden;
        }
        .sales-header {
            background: linear-gradient(135deg, #ffd700, #b8860b);
            color: #000;
            padding: 1.5rem;
            border-bottom: 1px solid #eee;
        }
        .sales-title {
            font-family: 'Playfair Display', serif;
            font-weight: 700;
            margin: 0;
        }
        .sales-body {
            padding: 2rem;
        }
        .table-responsive {
            overflow-x: auto;
        }
        .sales-table {
            width: 100%;
            border-collapse: collapse;
        }
        .sales-table th {
            background-color: #f8f9fa;
            color: #495057;
            font-weight: 600;
            padding: 1rem;
            text-align: left;
            border-bottom: 2px solid #dee2e6;
        }
        .sales-table td {
            padding: 1rem;
            border-bottom: 1px solid #dee2e6;
            vertical-align: top;
        }
        .sales-table tr:hover {
            background-color: rgba(255, 215, 0, 0.1);
        }
        .btn-back {
            background-color: #6c757d;
            color: white;
            margin-bottom: 1.5rem;
            transition: all 0.3s;
        }
        .btn-back:hover {
            background-color: #5a6268;
            color: white;
            transform: translateY(-2px);
        }
        .no-sales {
            text-align: center;
            padding: 2rem;
            color: #6c757d;
        }
        .footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 1rem;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
        .total-sales {
            font-size: 24px;
            font-weight: bold;
            text-align: right;
            margin-bottom: 20px;
            color: #28a745;
        }
        .service-details {
            max-width: 300px;
        }
        .service-item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 5px;
        }
        .service-name {
            font-weight: 500;
        }
        .service-price {
            color: #28a745;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar">
        <div class="container-fluid">
            <a class="navbar-brand" href="dashboard.php">Beauty Hotline Admin Panel</a>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="dashboard-container">
        <div class="total-sales">
            Total Sales: ₱<?php echo number_format($sale->getTotalSales(), 2); ?>
        </div>

        <div class="sales-card">
            <div class="sales-header">
                <h2 class="sales-title"><i class="fas fa-dollar-sign me-2"></i>Sales Records</h2>
            </div>
            <div class="sales-body">
                <?php if ($sales->rowCount() > 0): ?>
                    <div class="table-responsive">
                        <table class="sales-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Appointment ID</th>
                                    <th>Customer Name</th>
                                    <th>Services</th>
                                    <th>Amount</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($row = $sales->fetch(PDO::FETCH_ASSOC)): 
                                    $service_details = $sale->getSaleDetails($row['id']);
                                ?>
                                    <tr>
                                        <td><?php echo $row['id']; ?></td>
                                        <td><?php echo $row['appointment_id']; ?></td>
                                        <td><?php echo htmlspecialchars($row['customer_name']); ?></td>
                                        <td class="service-details">
                                            <?php while ($service = $service_details->fetch(PDO::FETCH_ASSOC)): ?>
                                                <div class="service-item">
                                                    <span class="service-name"><?php echo htmlspecialchars($service['service_name']); ?></span>
                                                    <span class="service-price">₱<?php echo number_format($service['service_price'], 2); ?></span>
                                                </div>
                                            <?php endwhile; ?>
                                        </td>
                                        <td>₱<?php echo number_format($row['total_amount'], 2); ?></td>
                                        <td><?php echo date('M j, Y', strtotime($row['sale_date'])); ?></td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="no-sales">
                        <i class="fas fa-dollar-sign fa-3x mb-3" style="color: #6c757d;"></i>
                        <h4>No sales records</h4>
                        <p>There are no sales records to display.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <p>© 2025 Beauty Hotline Admin Panel. All rights reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
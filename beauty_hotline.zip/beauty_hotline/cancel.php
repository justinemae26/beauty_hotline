<?php
include_once 'includes/Database.php';
include_once 'includes/Appointment.php';

$database = new Database();
$db = $database->getConnection();

$appointment = new Appointment($db);

$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $date = $_POST['date'];
    $time = $_POST['time'];
    
    // Check if the appointment date is in the future
    $appointment_datetime = new DateTime("$date $time");
    $current_datetime = new DateTime();
    
    if ($appointment_datetime > $current_datetime) {
        // Check if appointment exists with matching email
        $stmt = $appointment->checkAppointment($email, $date, $time);
        $appointment_exists = $stmt->rowCount() > 0;
        
        if ($appointment_exists) {
            // Get appointment ID
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $appointment_id = $row['id'];
            
            // Cancel the appointment with reason
            if ($appointment->cancelAppointmentById($appointment_id)) {
                $success_message = "Your appointment has been cancelled successfully.";
            } else {
                $error_message = "Failed to cancel appointment. Please try again.";
            }
        } else {
            $error_message = "No matching appointment found.";
        }
    } else {
        $error_message = "Cannot cancel past appointments.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Cancel Appointment - Beauty Hotline</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Great+Vibes&family=Pacifico&family=Playfair+Display:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-black">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <img src="assets/logo.png" alt="Logo" height="50">
                <span class="logo-text">Beauty Hotline</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link" href="about.php">About</a></li>
                    <li class="nav-item"><a class="nav-link" href="services.php">Services</a></li>
                    <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
                    <li class="nav-item"><a class="nav-link" href="list.php">Appointments</a></li>
                    <li class="nav-item"><a class="nav-link" href="reviews.php">Reviews</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Banner Section -->
    <div class="banner">
        <div class="card">
            <h2>Beauty Hotline</h2>
            <p>Radiance Starts Here – Book Your Escape Today!</p>
        </div>
    </div>

    <!-- Cancel Appointment Section -->
    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card shadow">
                    <div class="card-header bg-gold text-black">
                        <h3 class="mb-0">Cancel Appointment</h3>
                    </div>
                    <div class="card-body">
                        <?php if ($success_message): ?>
                            <div class="alert alert-success"><?php echo $success_message; ?></div>
                        <?php elseif ($error_message): ?>
                            <div class="alert alert-danger"><?php echo $error_message; ?></div>
                        <?php endif; ?>
                        
                        <form method="post" action="">
                            <div class="mb-3">
                                <label for="name" class="form-label">Your Name</label>
                                <input type="text" class="form-control" id="name" name="name" required>
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                            <div class="mb-3">
                                <label for="phone" class="form-label">Phone Number</label>
                                <input type="tel" class="form-control" id="phone" name="phone" required>
                            </div>
                            <div class="mb-3">
                                <label for="date" class="form-label">Appointment Date</label>
                                <input type="date" class="form-control" id="date" name="date" required>
                            </div>
                            <div class="mb-3">
                                <label for="time" class="form-label">Appointment Time</label>
                                <select class="form-control" id="time" name="time" required>
                                    <option value="">Select a time</option>
                                    <?php for($hour = 8; $hour <= 20; $hour++): ?>
                                        <option value="<?php echo sprintf("%02d:00:00", $hour); ?>">
                                            <?php echo sprintf("%02d:00 %s", $hour > 12 ? $hour - 12 : $hour, $hour >= 12 ? 'PM' : 'AM'); ?>
                                        </option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-danger w-100">Cancel Appointment</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer text-center">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <h5 class="footer-brand">
                        <a href="index.php" class="footer-logo-link">
                            <img src="assets/logo.png" alt="Logo" height="50">
                            <span class="footer-logo-text">Beauty Hotline</span>
                        </a>
                    </h5>
                </div>
                <div class="col-md-3">
                    <h6>Quick Links</h6>
                    <p><a href="about.php">About</a></p>
                    <p><a href="services.php">Services</a></p>
                    <p><a href="contact.php">Contact</a></p>
                </div>
                <div class="col-md-3">
                    <h6>Customer</h6>
                    <p><a href="list.php">Appointments</a></p>
                    <p><a href="reviews.php">Reviews</a></p>
                    <p><a href="cancel.php">Cancel Appointment</a></p>
                </div>
                <div class="col-md-3">
                    <h6>Have A Question?</h6>
                    <p><i class="fa-solid fa-location-dot"></i> Piaping Itum Macabalan, Cagayan de Oro City</p>
                    <p><i class="fa-solid fa-phone"></i> 09534704484</p>
                    <p><i class="fa-solid fa-envelope"></i> beauty.hotline@gmail.com</p>
                </div>
            </div>
            <p class="social-icons">
                &copy; 2025 Beauty Hotline. All rights reserved.
                <a href="#"><i class="fab fa-facebook fa-2x mx-3"></i></a>
                <a href="#"><i class="fab fa-twitter fa-2x mx-3"></i></a>
                <a href="#"><i class="fab fa-instagram fa-2x mx-3"></i></a>
            </p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
session_start();

if (!isset($_SESSION['loggedin'])) {
    header('Location: admin.php');
    exit;
}

include_once 'includes/Database.php';
include_once 'includes/Service.php';

$database = new Database();
$db = $database->getConnection();

$service = new Service($db);

// Get service ID from URL
$service->id = isset($_GET['id']) ? $_GET['id'] : die('ERROR: Service ID not found.');

// Read the service details
$service->readOne($service->id);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $service->category = $_POST['category'];
    $service->name = $_POST['name'];
    $service->description = $_POST['description'];
    $service->price = $_POST['price'];
    
    // Handle image upload if a new file was provided
    if (!empty($_FILES['image']['name'])) {
        $target_dir = "assets/services/";
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
        $file_extension = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
        $filename = uniqid() . '.' . $file_extension;
        $target_file = $target_dir . $filename;
        
        if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
            // Delete old image if it exists
            if (!empty($service->image) && file_exists($service->image)) {
                unlink($service->image);
            }
            $service->image = $target_file;
        }
    }
    
    if ($service->update()) {
        $success_message = "Service updated successfully!";
    } else {
        $error_message = "Failed to update service. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Service - Beauty Hotline</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Great+Vibes&family=Pacifico&family=Playfair+Display:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(135deg, #f8f9fa, #e9ecef);
            margin: 0;
            padding: 0;
            min-height: 100vh;
            position: relative;
            padding-bottom: 60px;
        }
        .navbar {
            background: linear-gradient(135deg, #ffd700, #b8860b);
            padding: 1rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .navbar-brand {
            font-size: 24px;
            font-weight: 700;
            color: #000;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .navbar-brand:hover {
            color: #fff;
        }
        .logout-btn {
            background-color: #dc3545;
            color: #fff;
            border: none;
            padding: 8px 16px;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .logout-btn:hover {
            background-color: #c82333;
        }
        .dashboard-container {
            padding: 2rem;
        }
        .service-card {
            background: #fff;
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            margin-bottom: 2rem;
            overflow: hidden;
        }
        .service-header {
            background: linear-gradient(135deg, #ffd700, #b8860b);
            color: #000;
            padding: 1.5rem;
            border-bottom: 1px solid #eee;
        }
        .service-title {
            font-family: 'Playfair Display', serif;
            font-weight: 700;
            margin: 0;
        }
        .service-body {
            padding: 2rem;
        }
        .btn-back {
            background-color: #6c757d;
            color: white;
            margin-bottom: 1.5rem;
            transition: all 0.3s;
        }
        .btn-back:hover {
            background-color: #5a6268;
            color: white;
            transform: translateY(-2px);
        }
        .footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 1rem;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar">
        <div class="container-fluid">
            <a class="navbar-brand" href="dashboard.php">Beauty Hotline Admin Panel</a>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="dashboard-container">
        <a href="admin_services.php" class="btn btn-back">
            <i class="fas fa-arrow-left me-2"></i>Back to Services
        </a>

        <div class="service-card">
            <div class="service-header">
                <h2 class="service-title"><i class="fas fa-edit me-2"></i>Edit Service</h2>
            </div>
            <div class="service-body">
                <?php if (isset($success_message)): ?>
                    <div class="alert alert-success"><?php echo $success_message; ?></div>
                <?php elseif (isset($error_message)): ?>
                    <div class="alert alert-danger"><?php echo $error_message; ?></div>
                <?php endif; ?>

                <form method="post" action="" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label for="category" class="form-label">Category</label>
                        <select class="form-control" id="category" name="category" required>
                            <option value="Hair Services" <?php echo $service->category === 'Hair Services' ? 'selected' : ''; ?>>Hair Services</option>
                            <option value="Makeup Services" <?php echo $service->category === 'Makeup Services' ? 'selected' : ''; ?>>Makeup Services</option>
                            <option value="Nail Services" <?php echo $service->category === 'Nail Services' ? 'selected' : ''; ?>>Nail Services</option>
                            <option value="Eyebrow and Eyelash Services" <?php echo $service->category === 'Eyebrow and Eyelash Services' ? 'selected' : ''; ?>>Eyebrow and Eyelash Services</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="name" class="form-label">Service Name</label>
                        <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($service->name); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="description" class="form-label">Description</label>
                        <textarea class="form-control" id="description" name="description" rows="3" required><?php echo htmlspecialchars($service->description); ?></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="price" class="form-label">Price</label>
                        <input type="number" class="form-control" id="price" name="price" step="0.01" min="0" value="<?php echo htmlspecialchars($service->price); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="image" class="form-label">Service Image</label>
                        <?php if (!empty($service->image)): ?>
                            <div>
                                <img src="<?php echo $service->image; ?>" class="service-image-preview" alt="Current Image">
                                <p class="text-muted">Current image</p>
                            </div>
                        <?php endif; ?>
                        <input type="file" class="form-control" id="image" name="image" accept="image/*">
                        <small class="text-muted">Leave blank to keep current image</small>
                    </div>
                    <button type="submit" class="btn btn-gold w-100">Update Service</button>
                </form>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <p>© 2025 Beauty Hotline Admin Panel. All rights reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
include_once 'includes/Database.php';
include_once 'includes/Service.php';

$database = new Database();
$db = $database->getConnection();

$service = new Service($db);

// Get all services grouped by category
$stmt = $service->readAll();
$services_by_category = [];
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $services_by_category[$row['category']][] = $row;
}

// Define the order of categories we want to display
$category_order = [
    'Hair Services',
    'Makeup Services',
    'Nail Services',
    'Eyebrow and Eyelash Services'
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Our Services - Beauty Hotline</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Great+Vibes&family=Pacifico&family=Playfair+Display:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <style>
        .services-title {
            font-family: 'Playfair Display', serif;
            font-weight: 700;
            color: #333;
            margin-bottom: 2rem;
            position: relative;
            display: inline-block;
        }
        .services-title::after {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
            width: 100px;
            height: 3px;
            background: linear-gradient(135deg, #ffd700, #b8860b);
        }
        .category-card {
            border: none;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
            transition: transform 0.3s;
        }
        .category-card:hover {
            transform: translateY(-10px);
        }
        .category-header {
            background: linear-gradient(135deg, #ffd700, #b8860b);
            color: #000;
            padding: 15px;
            text-align: center;
            font-weight: 700;
        }
        .service-item {
            padding: 15px;
            border-bottom: 1px solid #eee;
        }
        .service-item:last-child {
            border-bottom: none;
        }
        .service-name {
            font-weight: 600;
            color: #333;
        }
        .service-price {
            color: #b8860b;
            font-weight: 700;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <img src="assets/logo.png" alt="Logo" height="50">
                <span class="logo-text">Beauty Hotline</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link" href="about.php">About</a></li>
                    <li class="nav-item"><a class="nav-link" href="services.php">Services</a></li>
                    <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
                    <li class="nav-item"><a class="nav-link" href="list.php">Appointments</a></li>
                    <li class="nav-item"><a class="nav-link" href="reviews.php">Reviews</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Banner Section -->
    <div class="banner">
        <div class="card">
        <h2>Beauty Hotline</h2>
        <p>Radiance Starts Here – Book Your Escape Today!</p>
        </div>
    </div>

    <!-- Services Section -->
    <div class="container py-5">
        <h2 class="text-center mb-5 services-title">Beauty Services</h2>
        
        <div class="row">
            <?php foreach ($category_order as $category): ?>
                <div class="col-md-6 col-lg-3 mb-4">
                    <div class="category-card">
                        <div class="category-header">
                            <h4><?php echo htmlspecialchars($category); ?></h4>
                        </div>
                        <div class="card-body">
                            <?php if (isset($services_by_category[$category]) && !empty($services_by_category[$category])): ?>
                                <?php foreach ($services_by_category[$category] as $service): ?>
                                    <div class="service-item">
                                        <h5 class="service-name"><?php echo htmlspecialchars($service['name']); ?></h5>
                                        <p class="mb-1"><?php echo htmlspecialchars($service['description']); ?></p>
                                        <p class="service-price">₱<?php echo number_format($service['price'], 2); ?></p>
                                    </div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <div class="service-item text-center py-3">
                                    <p>No services available yet</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <h5 class="footer-brand">
                        <a href="index.php" class="footer-logo-link">
                            <img src="assets/logo.png" alt="Logo" height="50">
                            <span class="footer-logo-text">Beauty Hotline</span>
                        </a>
                    </h5>
                </div>
                <div class="col-md-3">
                    <h6>Quick Links</h6>
                    <p><a href="about.php">About</a></p>
                    <p><a href="services.php">Services</a></p>
                    <p><a href="contact.php">Contact</a></p>
                </div>
                <div class="col-md-3">
                    <h6>Customer</h6>
                    <p><a href="list.php">Appointments</a></p>
                    <p><a href="reviews.php">Reviews</a></p>
                    <p><a href="cancel.php">Cancel Appointment</a></p>
                </div>
                <div class="col-md-3">
                    <h6>Have A Question?</h6>
                    <p><i class="fa-solid fa-location-dot"></i> Piaping Itum Macabalan, Cagayan de Oro City</p>
                    <p><i class="fa-solid fa-phone"></i> 09534704484</p>
                    <p><i class="fa-solid fa-envelope"></i> beauty.hotline@gmail.com</p>
                </div>
            </div>
            <p class="text-center mt-4 copyright-text">
                &copy; 2025 Beauty Hotline. All rights reserved.
                <span class="social-icons">
                    <a href="#"><i class="fab fa-facebook mx-2"></i></a>
                    <a href="#"><i class="fab fa-twitter mx-2"></i></a>
                    <a href="#"><i class="fab fa-instagram mx-2"></i></a>
                </span>
            </p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
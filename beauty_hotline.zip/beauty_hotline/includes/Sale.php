<?php
class Sale {
    private $conn;
    private $table_name = "sales";
    private $items_table = "sale_items";

    public $id;
    public $appointment_id;
    public $customer_name;
    public $total_amount;
    public $sale_date;
    public $services = [];

    public function __construct($db) {
        $this->conn = $db;
    }

    function create() {
        // First create the sale record
        $query = "INSERT INTO " . $this->table_name . "
                SET appointment_id=:appointment_id, 
                customer_name=:customer_name, 
                total_amount=:total_amount";
        
        $stmt = $this->conn->prepare($query);
        
        $this->appointment_id = htmlspecialchars(strip_tags($this->appointment_id));
        $this->customer_name = htmlspecialchars(strip_tags($this->customer_name));
        $this->total_amount = htmlspecialchars(strip_tags($this->total_amount));
        
        $stmt->bindParam(":appointment_id", $this->appointment_id);
        $stmt->bindParam(":customer_name", $this->customer_name);
        $stmt->bindParam(":total_amount", $this->total_amount);
        
        if($stmt->execute()) {
            $this->id = $this->conn->lastInsertId();
            
            // Now add the sale items
            if (!empty($this->services)) {
                foreach ($this->services as $service) {
                    $query = "INSERT INTO " . $this->items_table . "
                            SET sale_id=:sale_id, 
                            service_name=:service_name, 
                            service_price=:service_price";
                    
                    $stmt = $this->conn->prepare($query);
                    
                    $service_name = htmlspecialchars(strip_tags($service['name']));
                    $service_price = htmlspecialchars(strip_tags($service['price']));
                    
                    $stmt->bindParam(":sale_id", $this->id);
                    $stmt->bindParam(":service_name", $service_name);
                    $stmt->bindParam(":service_price", $service_price);
                    
                    $stmt->execute();
                }
            }
            return true;
        }
        return false;
    }

    function readAll() {
        $query = "SELECT s.*, GROUP_CONCAT(si.service_name SEPARATOR ', ') as services 
                 FROM " . $this->table_name . " s
                 LEFT JOIN " . $this->items_table . " si ON s.id = si.sale_id
                 GROUP BY s.id
                 ORDER BY s.sale_date DESC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    function getTotalSales() {
        $query = "SELECT SUM(total_amount) as total FROM " . $this->table_name;
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        return $row['total'] ? $row['total'] : 0;
    }

    function getSaleDetails($sale_id) {
        $query = "SELECT * FROM " . $this->items_table . " WHERE sale_id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $sale_id);
        $stmt->execute();
        return $stmt;
    }
}
?>      
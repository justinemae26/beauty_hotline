<?php
class Appointment {
    private $conn;
    private $table_name = "appointments";

    public $id;
    public $name;
    public $email;
    public $phone;
    public $address;
    public $date;
    public $time;
    public $services;
    public $status;
    public $type;
    public $created_at;
    public $reason;

    public function __construct($db) {
        $this->conn = $db;
    }

    function create() {
        $query = "INSERT INTO " . $this->table_name . "
                SET name=:name, email=:email, phone=:phone, address=:address, 
                date=:date, time=:time, services=:services, type=:type, status='pending'";

        $stmt = $this->conn->prepare($query);

        $this->name = htmlspecialchars(strip_tags($this->name));
        $this->email = htmlspecialchars(strip_tags($this->email));
        $this->phone = htmlspecialchars(strip_tags($this->phone));
        $this->address = htmlspecialchars(strip_tags($this->address));
        $this->date = htmlspecialchars(strip_tags($this->date));
        $this->time = htmlspecialchars(strip_tags($this->time));
        $this->services = htmlspecialchars(strip_tags($this->services));
        $this->type = htmlspecialchars(strip_tags($this->type));

        $stmt->bindParam(":name", $this->name);
        $stmt->bindParam(":email", $this->email);
        $stmt->bindParam(":phone", $this->phone);
        $stmt->bindParam(":address", $this->address);
        $stmt->bindParam(":date", $this->date);
        $stmt->bindParam(":time", $this->time);
        $stmt->bindParam(":services", $this->services);
        $stmt->bindParam(":type", $this->type);

        if($stmt->execute()) {
            return true;
        }
        return false;
    }

    function updateStatus($id, $status, $reason = null) {
        try {
            $query = "UPDATE " . $this->table_name . " SET status=:status";
            
            if ($reason !== null) {
                // First check if the reason column exists
                $checkColumn = $this->conn->query("SHOW COLUMNS FROM " . $this->table_name . " LIKE 'reason'");
                if ($checkColumn->rowCount() > 0) {
                    $query .= ", reason=:reason";
                }
            }
            
            $query .= " WHERE id=:id";
            
            $stmt = $this->conn->prepare($query);
            
            $stmt->bindParam(":status", $status);
            if ($reason !== null && strpos($query, ':reason') !== false) {
                $stmt->bindParam(":reason", $reason);
            }
            $stmt->bindParam(":id", $id);
            
            return $stmt->execute();
        } catch (PDOException $e) {
            // Fallback if reason column doesn't exist
            if (strpos($e->getMessage(), 'reason') !== false) {
                $query = "UPDATE " . $this->table_name . " SET status=:status WHERE id=:id";
                $stmt = $this->conn->prepare($query);
                $stmt->bindParam(":status", $status);
                $stmt->bindParam(":id", $id);
                return $stmt->execute();
            }
            throw $e;
        }
    }

    function cancelAppointment($name, $email, $phone, $date, $time) {
        try {
            $query = "UPDATE " . $this->table_name . " 
                     SET status='rejected', reason='Cancelled by customer'
                     WHERE name=:name AND email=:email AND phone=:phone AND date=:date AND time=:time 
                     AND (status='accepted' OR status='pending')";
            
            $stmt = $this->conn->prepare($query);
            
            $stmt->bindParam(":name", $name);
            $stmt->bindParam(":email", $email);
            $stmt->bindParam(":phone", $phone);
            $stmt->bindParam(":date", $date);
            $stmt->bindParam(":time", $time);
            
            return $stmt->execute() && $stmt->rowCount() > 0;
        } catch (PDOException $e) {
            // Fallback if reason column causes error
            if (strpos($e->getMessage(), 'reason') !== false) {
                $query = "UPDATE " . $this->table_name . " 
                         SET status='rejected'
                         WHERE name=:name AND email=:email AND phone=:phone AND date=:date AND time=:time 
                         AND (status='accepted' OR status='pending')";
                
                $stmt = $this->conn->prepare($query);
                
                $stmt->bindParam(":name", $name);
                $stmt->bindParam(":email", $email);
                $stmt->bindParam(":phone", $phone);
                $stmt->bindParam(":date", $date);
                $stmt->bindParam(":time", $time);
                
                return $stmt->execute() && $stmt->rowCount() > 0;
            }
            throw $e;
        }
    }

    function cancelAppointmentById($id, $reason = 'Cancelled by customer') {
        try {
            $query = "UPDATE " . $this->table_name . " 
                     SET status='rejected', reason=:reason
                     WHERE id=:id AND (status='accepted' OR status='pending')";
            
            $stmt = $this->conn->prepare($query);
            
            $stmt->bindParam(":id", $id);
            $stmt->bindParam(":reason", $reason);
            
            return $stmt->execute() && $stmt->rowCount() > 0;
        } catch (PDOException $e) {
            // Fallback if reason column causes error
            if (strpos($e->getMessage(), 'reason') !== false) {
                $query = "UPDATE " . $this->table_name . " 
                         SET status='rejected'
                         WHERE id=:id AND (status='accepted' OR status='pending')";
                
                $stmt = $this->conn->prepare($query);
                $stmt->bindParam(":id", $id);
                return $stmt->execute() && $stmt->rowCount() > 0;
            }
            throw $e;
        }
    }

    function checkAppointment($email, $date, $time) {
        $query = "SELECT id FROM " . $this->table_name . " 
                 WHERE email = ? AND date = ? AND time = ? AND (status = 'accepted' OR status = 'pending')";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $email);
        $stmt->bindParam(2, $date);
        $stmt->bindParam(3, $time);
        $stmt->execute();
        return $stmt;
    }

    function completeAppointment($id) {
        $query = "UPDATE " . $this->table_name . " SET status='completed' WHERE id=:id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id);
        
        if($stmt->execute()) {
            return true;
        }
        return false;
    }

    function readAll($status = null) {
        $query = "SELECT * FROM " . $this->table_name;
        
        if($status) {
            $query .= " WHERE status=:status";
        }
        
        $query .= " ORDER BY date DESC, time DESC";
        
        $stmt = $this->conn->prepare($query);
        
        if($status) {
            $stmt->bindParam(":status", $status);
        }
        
        $stmt->execute();
        return $stmt;
    }

    function readOne($id) {
        $query = "SELECT * FROM " . $this->table_name . " WHERE id = ? LIMIT 0,1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if($row) {
            $this->id = $row['id'];
            $this->name = $row['name'];
            $this->email = $row['email'];
            $this->phone = $row['phone'];
            $this->address = $row['address'];
            $this->date = $row['date'];
            $this->time = $row['time'];
            $this->services = $row['services'];
            $this->status = $row['status'];
            $this->type = $row['type'];
            $this->created_at = $row['created_at'];
            $this->reason = $row['reason'] ?? null;
        }
    }
}
?> 